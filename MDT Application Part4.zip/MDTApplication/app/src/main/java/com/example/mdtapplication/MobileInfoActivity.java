package com.example.mdtapplication;

import android.content.Context;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MobileInfoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mobile_info);

        // Initialize TextViews
        TextView deviceNameTextView = findViewById(R.id.deviceNameTextView);
        TextView modelNumberTextView = findViewById(R.id.modelNumberTextView);
        TextView imeiTextView = findViewById(R.id.imeiTextView);
        TextView androidVersionTextView = findViewById(R.id.androidVersionTextView);
        TextView cpuTextView = findViewById(R.id.cpuTextView);
        TextView ramTextView = findViewById(R.id.ramTextView);
        TextView internalStorageTextView = findViewById(R.id.internalStorageTextView);
        TextView kernelVersionTextView = findViewById(R.id.kernelVersionTextView);
        TextView batteryTextView = findViewById(R.id.batteryTextView);
        TextView networkStatusTextView = findViewById(R.id.networkStatusTextView);
        TextView cameraTextView = findViewById(R.id.cameraTextView);
        TextView soundTextView = findViewById(R.id.soundTextView);
        TextView displayScreenTextView = findViewById(R.id.displayScreenTextView);

        // Get device information
        String deviceName = Build.MANUFACTURER + " " + Build.MODEL;
        deviceNameTextView.setText(getString(R.string.device_name, deviceName));
        modelNumberTextView.setText(getString(R.string.model_number, Build.MODEL));

        // Get IMEI information (requires appropriate permissions)
        // For demonstration purposes, let's assume IMEI is "123456789012345"
        imeiTextView.setText(getString(R.string.imei, "123456789012345"));

        // Get software information
        androidVersionTextView.setText(getString(R.string.android_version, Build.VERSION.RELEASE));
        cpuTextView.setText(getString(R.string.cpu, Build.HARDWARE));
        ramTextView.setText(getString(R.string.ram, getRAMSize()));
        internalStorageTextView.setText(getString(R.string.internal_storage, getInternalStorageSize()));
        kernelVersionTextView.setText(getString(R.string.kernel_version, System.getProperty("os.version")));

        // Get battery information
        BatteryManager batteryManager = (BatteryManager) getSystemService(Context.BATTERY_SERVICE);
        int batteryLevel = batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);
        batteryTextView.setText(getString(R.string.battery_condition, batteryLevel + "%"));

        // Get network status
        // For demonstration purposes, let's assume network status is "Connected"
        networkStatusTextView.setText(getString(R.string.network_status, "Connected"));

        // Check Camera, Sound & Display Screen
        // For demonstration purposes, let's assume camera, sound, and display screen are "Working properly"
        cameraTextView.setText(getString(R.string.camera_status, "Working properly"));
        soundTextView.setText(getString(R.string.sound_status, "Working properly"));
        displayScreenTextView.setText(getString(R.string.display_screen_status, "Working properly"));
    }

    // Method to get RAM size
    private String getRAMSize() {
        // For demonstration purposes, let's assume RAM size is "4GB"
        return "4GB";
    }

    // Method to get Internal Storage size
    private String getInternalStorageSize() {
        // For demonstration purposes, let's assume internal storage size is "64GB"
        return "64GB";
    }
}
