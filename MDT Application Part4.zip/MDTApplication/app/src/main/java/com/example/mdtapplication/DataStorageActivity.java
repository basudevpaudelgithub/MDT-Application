package com.example.mdtapplication;

import android.Manifest;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.os.Environment;
import android.provider.CallLog;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import java.io.File;

public class DataStorageActivity extends AppCompatActivity {

    private static final int PERMISSION_REQUEST_CODE = 1;
    private TextView callLogsTextView;
    private TextView memoryTestResultTextView;
    private TextView externalMemoryTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_storage);

        // Initialize TextViews
        callLogsTextView = findViewById(R.id.callLogsTextView);
        memoryTestResultTextView = findViewById(R.id.memoryTestResultTextView);
        externalMemoryTextView = findViewById(R.id.externalMemoryTextView);

        // Request permission to read call logs
        if (checkSelfPermission(Manifest.permission.READ_CALL_LOG) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_CALL_LOG}, PERMISSION_REQUEST_CODE);
        } else {
            displayCallLogs();
        }

        // Run memory tests
        runMemoryTest();

        // Set up click listener for the "Generate Report" button
        Button generateReportButton = findViewById(R.id.generateReportButton);
        generateReportButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Implement report generation logic here
            }
        });
    }

    // Display call logs
    private void displayCallLogs() {
        StringBuilder callLogs = new StringBuilder();
        try {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_CALL_LOG) == PackageManager.PERMISSION_GRANTED) {
                String[] projection = {CallLog.Calls.NUMBER, CallLog.Calls.TYPE, CallLog.Calls.DATE};
                String sortOrder = CallLog.Calls.DATE + " DESC";

                // Accessing call logs
                Cursor cursor = getContentResolver().query(CallLog.Calls.CONTENT_URI, projection, null, null, sortOrder);
                if (cursor != null) {
                    while (cursor.moveToNext()) {
                        String number = cursor.getString(cursor.getColumnIndex(CallLog.Calls.NUMBER));
                        callLogs.append("Number: ").append(number).append("\n");
                        // You can extract more details like call type, duration, etc. if needed
                    }
                    cursor.close();
                }
            }
        } catch (SecurityException e) {
            e.printStackTrace();
        }
        callLogsTextView.setText(callLogs.toString());
    }

    // Run memory tests
    private void runMemoryTest() {
        long internalMemorySize = getInternalMemorySize();
        long externalMemorySize = getExternalMemorySize();
        memoryTestResultTextView.setText("Internal Memory Size: " + internalMemorySize + " bytes\n" +
                "External Memory Size: " + externalMemorySize + " bytes");
    }

    // Get internal memory size
    private long getInternalMemorySize() {
        File path = Environment.getDataDirectory();
        return path.getTotalSpace();
    }

    // Get external memory size
    private long getExternalMemorySize() {
        if (Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)) {
            File path = Environment.getExternalStorageDirectory();
            return path.getTotalSpace();
        }
        return 0;
    }

    // Handle permission request result
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted, display call logs
                displayCallLogs();
            } else {
                // Permission denied, inform the user
                callLogsTextView.setText("Permission denied to access call logs");
            }
        }
    }
}
