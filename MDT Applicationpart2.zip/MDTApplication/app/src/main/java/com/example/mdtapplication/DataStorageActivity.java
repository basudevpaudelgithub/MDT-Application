package com.example.mdtapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class DataStorageActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_storage);
    }
}