package com.example.mdtapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.content.Intent;

import android.view.View;
import android.widget.Button;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        Button btnMobileInfo = findViewById(R.id.btnMobileInfo);
        Button btnSensorsTest = findViewById(R.id.btnSensorsTest);
        Button btnDataStorage = findViewById(R.id.btnDataStorage);

        btnMobileInfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, MobileInfoActivity.class));
            }
        });

        btnSensorsTest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, SensorsTestActivity.class));
            }
        });

        btnDataStorage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, DataStorageActivity.class));
            }
        });
    }
}