package com.example.mdtapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class SensorsTestActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sensors_test);
    }
}